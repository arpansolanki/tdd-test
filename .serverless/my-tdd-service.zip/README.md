This repository is used in [Quick Start to Test-Driven Development with Serverless Framework](https://serverless.com/blog/tdd-serverless/) tutorial

Some minor changes are made to original [aws-node-simple-http-endpoint](https://github.com/serverless/examples/tree/master/aws-node-simple-http-endpoint) service, for example time handler function is moved to `time` directory.
